Replication Materials for "Democratization and Linguistic Complexity: The Effect of Franchise Extension on Parliamentary Discourse"
by Arthur Spirling (arthur.spirling@nyu.edu), August 12, 2015

The files that accompany this readme allow the researcher to replicate all figures and tables (that rely on data gathered by the author) in the JOP publication above.

The key dataset is "bigframe.rdata" which contains an object called 'big.frame' consisting of 670091 rows * 13 columns.  This is the data used for the various summaries and regressions.  (this also exists as a .csv file for compatibility reasons)

There are 6 R scripts that reproduce the relevant figures and tables:
- Figures_and_Tables_1.R    -- replication of Table 2, Fig 1 and Fig 2
- Figures_and_Tables_2.R    -- replication of Fig 3, Fig 4, Fig 5
- Figures_and_Tables_3.R    -- replication of Fig 6 (+ execution of simple break test)
- Figures_and_Tables_4.R    -- replication of Table 4 and Fig 7
- Figures_and_Tables_5.R    -- replication of Fig 8
- Figures_and_Tables_6.R    -- replication of Fig 9

The work here relies on two R packages not written by the author: 'effects' and 'plm'.  These can be installed via the R console in the usual way.

Notice that Table 1 is derived from Mitch (1992), and readers should check the original work for replication.  Similarly, Table 3 are quotes taken directly from Hansard. 

Replication materials for analyzes performed in the online appendix are available from the author on request. 