#8/12/2015
#replication materials for Spirling "Democratization and Linguistic Complexity", JOP

#(Table 1 is derived from Mitch (1992) Table 2.3 -- see original source for replication)

#Table 2 is a summary of the FRE statistics for the sample,
#Figure 1 is a boxplot and histogram of the data
#Figure 2 is an overtime plot of the cabinet vs noncabinet MPs (means)

#load the data
#setwd("C:/Users/as9934/Dropbox/complexity/August2015/JOP_replication_data/")
load("bigframe.rdata")

## Fig 1, boxplot and hist
par(bg="white")
par(mfrow=c(1,2))
boxplot(big.frame$FK_read.ease, ylab="FRE", col="cornsilk2")
hist(big.frame$FK_read.ease, main="", xlab="", col="cornsilk2")
box()

##Table 2
print(summary(big.frame$FK_read.ease))

##Table 2 (std dev)
print(sd(big.frame$FK_read.ease))

##Fig 2: overtime plot of cab and non cab

#sessions are the time dummies
sessions <- as.character( unique(big.frame$year.dummy) )

#set up some vectors
wcountcab <- c()
wcountnon <- c()
FKcab <- c()
FKnon <- c()

for(i in 1:length(unique(big.frame$year.dummy))){
  
  sub <- big.frame[big.frame$year.dummy==unique(big.frame$year.dummy)[i],]
  
  subcab <- sub[sub$cabinet==1,]
  wcountcab <- c(wcountcab, mean(subcab$word.count))
  FKcab <- c(FKcab, mean(subcab$FK_read.ease))
  
  
  subnon <- sub[sub$cabinet==0,]
  wcountnon <- c(wcountnon, mean(subnon$word.count))
  FKnon <- c(FKnon, mean(subnon$FK_read.ease))
  
}




#plot mean FRE scores for cab and noncab over time
par(mfrow=c(1,1))
par(bg='cornsilk1')


plot(1:length(sessions), FKcab, axes=F, pch=22, col="black", bg="pink", cex=1.5,
     ylab="FRE", xlab="" )
axis(1, at=1:length(sessions), labels=sessions)
axis(2)
points(1:length(sessions), FKnon, pch=21, col="black", bg="green", cex=1.5)
box()
legend("topleft", pch=c(22,21), col=c("black","black"), pt.bg=c("pink","green"), 
       legend=c("cabinet","non-cabinet"), pt.cex=c(1.5,1.5), bty="n")

low.cab <- lowess(1:length(sessions),FKcab)
lines(low.cab$x, low.cab$y, lwd=4, col="pink")

low.non <- lowess(1:length(sessions), FKnon)
lines(low.non$x, low.non$y, lwd=4, col="green")